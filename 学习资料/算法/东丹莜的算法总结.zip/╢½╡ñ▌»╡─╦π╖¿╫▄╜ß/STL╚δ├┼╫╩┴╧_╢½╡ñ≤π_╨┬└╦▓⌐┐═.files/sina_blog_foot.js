document.write('\
  <div class="sinaBottom">\
    <center>\
      <a target="_blank" href="http://blog.sina.com.cn/admin/advice/advice_list.php">新浪BLOG意见反馈留言板</a>　<a onclick="window.open (\'http://control.blog.sina.com.cn/admin/advice/impeach.php?url=' + escape(document.location.href), '\', \'\',\'height=495, width=510, top=0, left=0, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=n o, status=no\');" href="javascript:;">不良信息反馈</a>　电话：95105670 提示音后按2键（按当地市话标准计费）　欢迎批评指正\
    </center>\
    <p> <a target="_blank" href="http://corp.sina.com.cn/chn/">新浪简介</a> | <a target="_blank" href="http://corp.sina.com.cn/eng/">About Sina</a> | <a target="_blank" href="http://ads.sina.com.cn/">广告服务</a> | <a target="_blank" href="http://www.sina.com.cn/contactus.html">联系我们</a> | <a target="_blank" href="http://corp.sina.com.cn/chn/sina_job.html">招聘信息</a> | <a target="_blank" href="http://www.sina.com.cn/intro/lawfirm.shtml">网站律师</a> | <a target="_blank" href="http://english.sina.com">SINA English</a> | <a target="_blank" href="http://members.sina.com.cn/apply/">会员注册</a> | <a target="_blank" href="http://blog.sina.com.cn/lm/help/2009/index.html">产品答疑</a> </p>\
    <p class="copyright"> Copyright &copy; 1996 - 2010 SINA Corporation,  All Rights Reserved  <br/>\
    </p>\
    <div>新浪公司 <a target="_blank" href="http://www.sina.com.cn/intro/copyright.shtml">版权所有</a></div>\
  </div>\
');