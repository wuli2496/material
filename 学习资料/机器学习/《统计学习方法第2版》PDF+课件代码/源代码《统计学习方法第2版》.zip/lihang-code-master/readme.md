**代码目录**

第1章 统计学习方法概论

第2章 感知机

第3章 k近邻法

第4章 朴素贝叶斯

第5章 决策树

第6章 逻辑斯谛回归

第7章 支持向量机

第8章 提升方法

第9章 EM算法及其推广

第10章 隐马尔可夫模型

第11章 条件随机场

第12章 监督学习方法总结

-----------
参考：
https://github.com/wzyonggege/statistical-learning-method

https://github.com/WenDesi/lihang_book_algorithm

https://blog.csdn.net/tudaodiaozhale

代码整理和修改：机器学习初学者  

微信公众号：机器学习初学者 ![gongzhong](images/gongzhong.jpg)


知识星球：黄博的机器学习圈子![xingqiu](images/zhishixingqiu1.jpg)

[知乎](https://www.zhihu.com/people/fengdu78)