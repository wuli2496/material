package com.example.android.fileAndroid;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;

public class FileAndroid extends Activity {
    
    private EditText name;
    private Button button_input;
    private Button button_display;
    private Button button_clear;
    private SharedPreferences settings;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

    	name = (EditText) findViewById(R.id.name);
    	button_input = (Button) findViewById(R.id.button_input);
    	button_display = (Button) findViewById(R.id.button_display);
    	button_clear = (Button) findViewById(R.id.button_clear);

    	// ����SharedPreference����
    	settings = this.getSharedPreferences("Demo", MODE_PRIVATE);

    	button_input.setOnClickListener(new OnClickListener(){
    	    public void onClick(View v) {
    		// �洢���ݵ�XML��¼�ļ�
    		SharedPreferences.Editor editor = settings.edit();

    		//�洢name
    		editor.putString("name", name.getText().toString());
    		editor.commit();
    		Toast.makeText(FileAndroid.this, R.string.save_message,
    			Toast.LENGTH_SHORT).show();
    	    }
    	});

    	button_display.setOnClickListener(new OnClickListener() {
    	    public void onClick(View v) {
    		Intent i = new Intent(FileAndroid.this,
    			ShareValueActivity.class);
    		startActivity(i);
    	    }
    	});

    	button_clear.setOnClickListener(new OnClickListener() {
    	    public void onClick(View v) {
    		SharedPreferences.Editor editor = settings.edit();
    		// ���XML��¼�ļ�������
    		editor.clear().commit();
    		Toast.makeText(FileAndroid.this, R.string.clear_message,
    			Toast.LENGTH_SHORT).show();
    	    }
    	});
        
    }
}