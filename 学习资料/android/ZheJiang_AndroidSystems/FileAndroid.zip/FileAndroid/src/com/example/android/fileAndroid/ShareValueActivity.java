package com.example.android.fileAndroid;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class ShareValueActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

	super.onCreate(savedInstanceState);
	setContentView(R.layout.share);
	TextView view = (TextView)findViewById(R.id.share);
	SharedPreferences settings = this.getSharedPreferences("Demo",
		MODE_PRIVATE);
	String name_value = settings.getString("name", "");
	view.setText(name_value);
    }
}
