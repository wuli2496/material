package com.android.layoutTest;

import java.util.Calendar;

import android.app.Activity;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

public class TimePickerActivity extends Activity
{
    private DatePicker datePicker;
    private TimePicker timePicker;
    private static Calendar calendar = Calendar.getInstance();
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.timepicker);
	timePicker = (TimePicker)findViewById(R.id.timepicker);
	//���ü����������û��޸�ʱ�䣬onTimeChanged����������
	timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener(){
	    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
		StringBuffer buffer = new StringBuffer();
		buffer.append(hourOfDay<10?"0"+hourOfDay:hourOfDay);
		buffer.append(":").append(minute);
		Toast.makeText(TimePickerActivity.this, buffer.toString(), Toast.LENGTH_SHORT).show();
	    }
	});
	datePicker = (DatePicker)findViewById(R.id.datepicker);
	int year = calendar.get(Calendar.YEAR);
	int month = calendar.get(Calendar.MONTH);
	int day = calendar.get(Calendar.DAY_OF_MONTH);
	//���ü����������û��޸�����,onDateChanged()������
	datePicker.init(year, month, day, new DatePicker.OnDateChangedListener(){
	    public void onDateChanged(DatePicker view, int year,
		    int monthOfYear, int dayOfMonth) {
		
	    }
	    
	});
    }

}
