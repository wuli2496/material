package com.android.layoutTest;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class SpinnerActivity extends Activity {

    private Spinner spinner;
    private static final String[] CITY = {
    	"����", "�Ϻ�", "����", "��ɽ" };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.spinner);
	spinner = (Spinner) findViewById(R.id.spinner);
	//�����鴴��ArrayAdapter
	ArrayAdapter<String> adapter =
		new ArrayAdapter<String>(this,
		android.R.layout.simple_spinner_item,
		CITY);
	adapter
		.setDropDownViewResource(
				android.R.layout.simple_spinner_dropdown_item);
	spinner.setAdapter(adapter);
	//����Spinner��Ŀ��ѡ���¼�
	spinner
		.setOnItemSelectedListener(
				new AdapterView.OnItemSelectedListener() {
		    public void onItemSelected(AdapterView<?> arg0, View arg1,
			    int arg2, long arg3) {
			//��ʾ�û�ѡ�еĳ���
			Toast.makeText(SpinnerActivity.this, CITY[arg2],
				Toast.LENGTH_SHORT).show();
		    }
		    public void onNothingSelected(AdapterView<?> arg0) {
		    }
		});
    }

}
