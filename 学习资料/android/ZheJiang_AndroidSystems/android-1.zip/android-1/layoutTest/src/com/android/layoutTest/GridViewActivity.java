package com.android.layoutTest;

import java.util.Random;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.AdapterView.OnItemClickListener;

public class GridViewActivity extends Activity
	implements OnItemClickListener {

    private static final int[] mThumbIds = { R.drawable.pic1,
	    R.drawable.pic2, R.drawable.pic3, R.drawable.pic4, R.drawable.pic5,
	    R.drawable.pic6, R.drawable.pic7, R.drawable.pic8, R.drawable.pic9,
	    R.drawable.pic10, R.drawable.pic11, R.drawable.pic12,
	    R.drawable.pic1, R.drawable.pic2, R.drawable.pic3, R.drawable.pic4,
	    R.drawable.pic5, R.drawable.pic6, R.drawable.pic7, R.drawable.pic8,
	    R.drawable.pic9, R.drawable.pic10, R.drawable.pic11,
	    R.drawable.pic12 };
    private GridView gView;
    //�洢������ҵ�ͼƬ
    private int[] map = new int[24];
    private int[] target = new int[24];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.gridview);
	initMap();
	gView = (GridView) findViewById(R.id.myGrid);
	gView.setOnItemClickListener(this);
	gView.setAdapter(new ImageAdapter(this));

    }

    private void initMap() {
	//��ʼ��target��Ĭ��ΪR.drawable.hide
	for (int i = 0; i < target.length; i++) {
	    target[i] = R.drawable.hide;
	}
	int[] temp = new int[mThumbIds.length];
	System.arraycopy(mThumbIds,0,temp,0,temp.length);
	int max = temp.length;
	Random r = new Random();
	//����㷨������ͼƬλ��
	for (int i = 0; i < map.length; i++) {
	    int index = (r.nextInt() >>> 1) % max;
	    map[i] = temp[index];
	    int t = temp[index];
	    temp[index] = temp[max - 1];
	    temp[max - 1] = t;
	    max--;
	}
    }

    //��GridView��ͼƬ��������˷���������
    public void onItemClick(
    		AdapterView<?> arg0,
    		View arg1,
    		int arg2, long arg3) {
	if(arg1 instanceof ImageView){
	    ImageView view = (ImageView)arg1;
	    view.setImageResource(map[arg2]);
	}
    }

    class ImageAdapter extends BaseAdapter {
	public ImageAdapter(Context c) {
	    mContext = c;
	}

	public int getCount() {
	    return mThumbIds.length;
	}

	public Object getItem(int position) {
	    return position;
	}

	public long getItemId(int position) {
	    return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
	    ImageView imageView;
	    if (convertView == null) {
		imageView = new ImageView(mContext);
		imageView.setLayoutParams(new GridView.LayoutParams(80, 50));
		imageView.setAdjustViewBounds(false);
		imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
		imageView.setPadding(8, 8, 8, 8);
	    } else {
		imageView = (ImageView) convertView;
	    }
	    imageView.setImageResource(target[position]);
	    return imageView;
	}

	private Context mContext;

    }

}
