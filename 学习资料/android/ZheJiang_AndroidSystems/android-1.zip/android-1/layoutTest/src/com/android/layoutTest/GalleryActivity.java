package com.android.layoutTest;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;

public class GalleryActivity extends Activity
{
    private static final Integer[] IMAGES = {
    		R.drawable.gallery_photo_0,
    		R.drawable.gallery_photo_1,
            R.drawable.gallery_photo_2,
            R.drawable.gallery_photo_3,
            R.drawable.gallery_photo_4,
            R.drawable.gallery_photo_5,
            R.drawable.gallery_photo_6,
            R.drawable.gallery_photo_7,
            R.drawable.gallery_photo_8,
            R.drawable.gallery_photo_9
    };
    private Gallery gallery;
    private ImageView selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.gallery);
	gallery = (Gallery)findViewById(R.id.gallery);
	gallery.setAdapter(new ImageAdapter(this));
	//��ʾ��ѡ�е�ͼƬ
	selected = (ImageView)findViewById(R.id.selected);
	gallery.setOnItemClickListener(
			new AdapterView.OnItemClickListener(){
	    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
		    long arg3) {
		selected.setImageResource(IMAGES[arg2]);
	    }
	});
    }
    
    public class ImageAdapter extends BaseAdapter
    {
        public ImageAdapter(Context c) {
            mContext = c;
        }

        public int getCount() {
            return IMAGES.length;
        }

        public Object getItem(int position) {
            return position;
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView i = new ImageView(mContext);
            i.setImageResource(IMAGES[position]);
            i.setScaleType(ImageView.ScaleType.FIT_XY);
            i.setLayoutParams(new Gallery.LayoutParams(136, 88));
            return i;
        }
        private Context mContext;
    }
}
