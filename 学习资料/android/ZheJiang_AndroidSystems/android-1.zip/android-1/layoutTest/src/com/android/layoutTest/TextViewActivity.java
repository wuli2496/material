package com.android.layoutTest;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class TextViewActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.textview);
		TextView view = (TextView) findViewById(R.id.single);
		view.setOnLongClickListener(
				new View.OnLongClickListener() {
			public boolean onLongClick(View v) {
				TextView tv = (TextView) v;
				Toast.makeText(TextViewActivity.this,
						tv.getText(),
						Toast.LENGTH_SHORT).show();
				return true;
			}

		});
	}

}
