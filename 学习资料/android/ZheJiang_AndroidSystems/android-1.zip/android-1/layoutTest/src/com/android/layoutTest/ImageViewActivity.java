package com.android.layoutTest;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

public class ImageViewActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.imageview);
	
		ImageView scale = (ImageView)findViewById(R.id.scale);
		//����Դ�ļ����Bitmap����
		Bitmap pic = BitmapFactory.decodeResource(
				getResources(),
				R.drawable.jadde);
		//��ѯbitmap�ĸ߶ȺͿ���
		int w = pic.getWidth();
		int h = pic.getHeight();
		//����ͼƬ
		Bitmap scaled = Bitmap.createScaledBitmap(
				pic, 100, 100*h/w, false);
		scale.setImageBitmap(scaled);
	}

}
