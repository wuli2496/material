package com.example.android.ButtonTest;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ButtonTest extends Activity
	implements Runnable
{
	TextView	msg;
	EditText	edt;
	ProgressBar	pbr;
	int			num;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        msg = (TextView)findViewById(R.id.TextView01);
        edt = (EditText)findViewById(R.id.EditText01);
        pbr = (ProgressBar)findViewById(R.id.ProgressBar01);
        num=0;	pbr.setProgress(0);
        
        Button btn = (Button)findViewById(R.id.Button01);
        btn.setOnClickListener(
        		new OnClickListener(){
			public void onClick(View v) {
				msg.setText(edt.getText());
				new Thread(ButtonTest.this).start();
			}
			});
        Button clr = (Button)findViewById(R.id.Button02);
        clr.setOnClickListener(
        		new OnClickListener(){
			public void onClick(View v) {
				msg.setText("");
				edt.setText("");
		        pbr.setProgress(0);
				Toast.makeText(ButtonTest.this,
						"�����",
						Toast.LENGTH_SHORT).show();
			}
			});
    }
    
	public void run() {
		while(num<100){
			num++;
	        pbr.setProgress(num);
			try {
				Thread.sleep(50);
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
		}
	}
}