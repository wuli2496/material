package com.android.ProgressBarAct;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ProgressBar;

public class ProgressBarAct extends Activity
	implements Runnable
{
		private boolean visible = false;
		private ProgressBar progress;
		private int progressCurrent;
		private int progressSecond;
		private Handler handler = new Handler();

		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			//������Title����ʾProgressbar
			requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
			setContentView(R.layout.main);
			//����bar�Ŀɼ���
			setProgressBarIndeterminateVisibility(visible);
			progress = (ProgressBar) findViewById(R.id.progress);
			//������̨�̸߳���progress�Ľ���
			new Thread(this).start();
			Button button = (Button) findViewById(R.id.toggle);
			button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					visible = !visible;
					//���bar�Ŀɼ���
					setProgressBarIndeterminateVisibility(visible);
				}
			});
		}

		public void run() {
			progressCurrent = progress.getProgress();
			progressSecond = progress.getSecondaryProgress();
			while (progressCurrent < 100) {
				//ʹ��handler�ڵ����߳��и��½���
				handler.post(new Runnable() {
					public void run() {
						//����progress�Ľ���
						progress.setProgress(++progressCurrent);
						progress.setSecondaryProgress(++progressSecond);
					}
				});
				try {
					Thread.sleep(50);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
			}
		}

	}
