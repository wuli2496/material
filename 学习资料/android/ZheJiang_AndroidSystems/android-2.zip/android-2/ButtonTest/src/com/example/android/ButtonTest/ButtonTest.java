package com.example.android.ButtonTest;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class ButtonTest extends Activity
	implements Runnable, OnClickListener
{
	TextView	msg;
	EditText	edt;
	ProgressBar	pbr;
	int			num, max;
	MediaPlayer	player;
	Thread		thr;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        msg = (TextView)findViewById(R.id.TextView01);
        edt = (EditText)findViewById(R.id.EditText01);
        pbr = (ProgressBar)findViewById(R.id.ProgressBar01);
        num=0;	max=100;
        pbr.setProgress(0);
        pbr.setOnClickListener(
        		new OnClickListener(){
        			public void onClick(View v) {
        				if(player.isPlaying())player.pause();
        				else player.start();
//        				thr.stop();

        				Toast.makeText(
    							ButtonTest.this,
    							"",
    							Toast.LENGTH_SHORT).show();
        			}
        		});
        
        Button btn = (Button)findViewById(R.id.Button01);
        btn.setOnClickListener(
        		new OnClickListener(){
			public void onClick(View v) {
				msg.setText(edt.getText());
				thr = new Thread(ButtonTest.this);
				thr.start();
			}
			});
        Button ply = (Button)findViewById(R.id.Button03);
        ply.setOnClickListener(new PlyStart());
        Button stp = (Button)findViewById(R.id.Button04);
        stp.setOnClickListener(new PlyStart());

        Button clr = (Button)findViewById(R.id.Button02);
        clr.setOnClickListener(this);
    }
    
	public void onClick(View v)
	{
		try{
			Intent it = new Intent(
				ButtonTest.this,
				Another.class);
			it.putExtra("name", "value");
			startActivity(it);
		}catch(Exception ex){
			Toast.makeText(
					ButtonTest.this,
					ex.toString(),
					Toast.LENGTH_SHORT).show();
		}
	}
	

	public void run()
	{
		while(num<max){
			num++;
	        pbr.setProgress(num);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
		}
	}

	class PlyStart implements OnClickListener
	{
		public void onClick(View v) {
			String ms = "/sdcard/xuwei.mp3";
		try {
			if(player==null){
				player = new MediaPlayer();
//				player.setOnCompletionListener(compListener);
        	} else {
        		if(player.isPlaying())
        			player.stop();
        		else {
	        		player.reset();
	            	// ��������Դ
	            	player.setDataSource(ms);
	           		player.prepare();
	           		max = player.getDuration()/1000;
	           		num = 0;
					new Thread(ButtonTest.this).start();
	           		Toast.makeText(
							ButtonTest.this,
							"start: "+max,
							Toast.LENGTH_SHORT).show();
	           		player.start();
        		}
        	}
		}catch(Exception ex){
				Toast.makeText(
					ButtonTest.this,
					ex.toString(),
					Toast.LENGTH_SHORT).show();				}
		}
	}
}