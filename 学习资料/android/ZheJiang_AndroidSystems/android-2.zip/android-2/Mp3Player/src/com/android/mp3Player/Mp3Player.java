package com.android.mp3Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Mp3Player extends ListActivity
{
	private String		rootdir= "/sdcard/";
	private String		thedir="";
	private Button		stop;
    private List<String> items = null;
    private String[]	mp3s;
//	private MediaPlayer player = null;
	private int			current;
	SharedPreferences	settings;

	private Mp3Receiver	receiver;

	class Mp3Receiver extends BroadcastReceiver
	{
		@Override
		public void onReceive(Context arg0, Intent arg1) {
			String action = arg1.getAction();
			if (action.equals(Mp3Service.MUSIC_COMPLETED)) {
				//��MusicService���ܹ㲥��Ϣ������Toast
				String msg = arg1.getStringExtra("msg");
				Toast.makeText(Mp3Player.this, msg, Toast.LENGTH_SHORT)
						.show();
			}
		}
	}

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		//��ʼ��stop
		stop = (Button) findViewById(R.id.stop);
		stop.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				//ֹͣService
				Intent intent = new Intent(
						Mp3Player.this,
						Mp3Service.class);
				stopService(intent);
			}
		});
		
		settings = this.getSharedPreferences("Mp3Now", MODE_PRIVATE);
		thedir = settings.getString("thedir", "");
		if(thedir.equals("")){
			thedir=rootdir;
		}
		fill(thedir);
		current= Integer.parseInt(settings.getString("current", "-1"));
		if(current>=0)play();
    }

	@Override
	public void onDestroy() {
		super.onDestroy();
	}
	
	public void play()
	{
		//����Service,����滻ΪBlockServie���������û�����
		Intent intent = new Intent(
				Mp3Player.this,
				Mp3Service.class);
		intent.putExtra("thedir", thedir);
		intent.putExtra("current", current);
		intent.putExtra("mp3s", mp3s);
		startService(intent);
	}
    
	@Override
    protected void onListItemClick(ListView l, View v, int selectionRow, long id)
	{
        if (selectionRow == 0) {
            fill(rootdir);
        } else {
            File file = new File(thedir+items.get(selectionRow));
            if (file.isDirectory())
            	fill(thedir+items.get(selectionRow));
            else {
        		current=selectionRow-1;
        		play();
            }
        }
    }

    public void fill(String dr)
    {
    	File	dir	= new File(dr);
    	File[] 	files = dir.listFiles();
    	thedir = dir.getPath()+"/";

    	mp3s = new String[files.length];
        items = new ArrayList<String>();
        items.add(thedir);
        
        int i=0;
        for (File f : files){
            items.add(mp3s[i++]=f.getName());
        }

        ArrayAdapter<String> fileList
        		= new ArrayAdapter<String>(this, R.layout.item, items);
        setListAdapter(fileList);
    }

	@Override
	protected void onPause() {
		//ע��BroadcastReceiver
		unregisterReceiver(receiver);
		super.onPause();
	}

	@Override
	protected void onResume() {
		IntentFilter filter = new IntentFilter(Mp3Service.MUSIC_COMPLETED);
		if (receiver == null)
			receiver = new Mp3Receiver();
		//ע��BroadcastReceiver
		registerReceiver(receiver, filter);
		super.onResume();
	}
}
