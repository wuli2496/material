package com.android.mp3Player;

import java.io.IOException;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class Mp3Service extends Service
{
	private Looper looper;
	private Handler handler;
	private NotificationManager nMgr;
	private static final int START = 0;
	private static final int STOP = 1;

	private String		thedir="";
    private String[]	mp3s;
    private OnCompletionListener compListener;
	private MediaPlayer player = null;
	private int			current;
	
	public static final String MUSIC_COMPLETED = "com.android.mp3Player.MUSIC_COMPLETED";

	private TelephonyManager telephony;
	PhoneStateListener phoneListener =
		new PhoneStateListener()
	{
		@Override
		public void onCallForwardingIndicatorChanged(boolean cfi)
		{
		}

		@Override
		public void onCallStateChanged(int state, String incomingNumber)
		{
			switch (state) {
			case TelephonyManager.CALL_STATE_IDLE:
				player.start();
				break;
			case TelephonyManager.CALL_STATE_OFFHOOK:
				if(player.isPlaying())player.pause();
				break;
			case TelephonyManager.CALL_STATE_RINGING:
				player.pause();
				break;
			}
		}
	};

	private class ServiceHandler extends Handler
	{
		//�ڹ�������ΪHandlerָ��looper
		public ServiceHandler(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg)
		{
			switch (msg.what) {
			case START:		play();		break;
			case STOP:		stop();		break;
			default:		break;
			}
		}
	}

	@Override
	public IBinder onBind(Intent arg0)
	{
		//���ܱ������ͻ��˰󶨣�����null
		return null;
	}

	@Override
	public void onCreate()
	{
		super.onCreate();
		//�ڵ����߳��в���MP3�ļ�
		HandlerThread thread = new HandlerThread("Mp3Service",
				HandlerThread.NORM_PRIORITY);
		thread.start();
		//������̵߳�looper����
		looper = thread.getLooper();
		//Ĭ������£�Handler��looper�Ǵ��������߳����
		//���ｫ���̵߳�looper���ݸ�Handler
		handler = new ServiceHandler(looper);

        compListener = new OnCompletionListener(){
			public void onCompletion(MediaPlayer mp) {
				// TODO Auto-generated method stub
				if(current >= mp3s.length)current=0;
				else current++;
				play();
			}
        };
        
		if (telephony == null)
			telephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		telephony.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE);
	}

	@Override
	public void onDestroy()
	{
		super.onDestroy();
		//ȡ��Notification
		nMgr.cancel(R.string.service_started);
		//ֹͣ����
		handler.sendEmptyMessage(STOP);
	}

	@Override
	public void onStart(Intent intent, int startId)
	{
		super.onStart(intent, startId);
		thedir = intent.getStringExtra("thedir");
		mp3s = intent.getStringArrayExtra("mp3s");
		current= intent.getIntExtra("current",-1);

		Toast.makeText(Mp3Service.this, mp3s[current],
				Toast.LENGTH_SHORT).show();

		
		//��ʼ��������
		handler.sendEmptyMessage(START);
		showNotification();
	}

	private void showNotification()
	{
		CharSequence text = getText(R.string.service_started);
		Notification notifi = new Notification(R.drawable.stat_sample, text,
				System.currentTimeMillis());
		//�û����Դ������б��У����»ص�MainActivity
		PendingIntent pIntent = PendingIntent.getActivity(this, 0,
				new Intent(this, Mp3Player.class), 0);
		notifi.setLatestEventInfo(this, getText(R.string.notification_title),
				text, pIntent);
		if (nMgr == null)
			nMgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		//ʹ��R.string.service_started��Ϊid��֤��id��Ψһ�ԣ��Һܷ���
		nMgr.notify(R.string.service_started, notifi);
	}

	private void play()
	{
		String ms = thedir+mp3s[current];
		try {
			if(player==null){
				player = new MediaPlayer();
				player.setOnCompletionListener(compListener);
//        		player.setOnPreparedListener(prepListener);
        	} else player.reset();
        	// ��������Դ
        	player.setDataSource(ms);
       		player.prepare();
       		player.start();
	    	// ����SharedPreference����
			SharedPreferences settings = this.getSharedPreferences("Mp3Now", MODE_PRIVATE);
	    	SharedPreferences.Editor editor = settings.edit();
	    	//�洢name
	    	editor.putString("thedir", thedir);
	    	editor.putString("current", ""+current);
	    	editor.commit();
       	} catch (IllegalArgumentException e) {
       	    e.printStackTrace();
       	} catch (IllegalStateException e) {
       	    e.printStackTrace();
       	} catch (IOException e) {
       	    e.printStackTrace();
       	}
	}

	private void stop()
	{
		if (player != null){
			player.release();
		}
		//һ��Ҫ��looper�˳�����Լ��Դ
		looper.quit();
	}
}
