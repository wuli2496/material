package com.android.helloAndroid;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.*;
import android.view.View.OnClickListener;
import android.widget.*;

public class HelloAndroid extends Activity {

	private static final int MENU_SAVE = 1;
	private static final int MENU_QUIT = 9;
	private Menu		menu;
	private TextView	msg;
	private EditText	txt;
	private Button		btn, stp;
	private ProgressBar	pbr;
	
	private TheThr		thr;
	private int			num=0;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
//		onCreateOptionsMenu(menu);
        msg =(TextView)findViewById(R.id.TextView01);
        txt =(EditText)findViewById(R.id.EditText01);
        btn =(Button)findViewById(R.id.Button01);
        stp =(Button)findViewById(R.id.Button02);
        pbr =(ProgressBar)findViewById(R.id.progressbar01);
		pbr.setMax(100);//�����ܳ���Ϊ100

		thr = new TheThr(pbr);
//		thr.start();
		
        btn.setOnClickListener(new OnClickListener(){
    	    public void onClick(View v) {
        		msg.setText(txt.getText());
        		pbr.setProgress(num);//�����Ѿ���������Ϊ0
        		num+=10; if(num>100)num=0;
        		thr.start();
        	}
        });
        stp.setOnClickListener(new OnClickListener(){
    	    public void onClick(View v) {
    	    	num	=0;
        		thr.interrupt();
        		msg.setText("stop");
        	}
        });
    }
    /* Creates the menu items */
    public boolean onCreateOptionsMenu(Menu menu)
    {
    	menu.add(0, MENU_SAVE, 0, "Save");
    	menu.add(0, MENU_QUIT, 0, "Quit");
    	return true;
    }
    /* Handles item selections */
    public boolean onOptionsItemSelected(MenuItem item)
    {
    	switch (item.getItemId()) {
    	case MENU_SAVE:		//save();
    		return true;
    	case MENU_QUIT:		//quit();
    		return true;
    	}
    	return false;
    }
    
    class TheThr extends Thread
    {
    	ProgressBar		pbr;
    	TheThr(ProgressBar pbr)
    	{
    		this.pbr = pbr;
    	}
    	public void run()
    	{
    		try {
        		while(true){
        			pbr.setProgress(num);//�����Ѿ���������Ϊ0
        			num+=1; if(num>100)num=0;
        			Thread.sleep(100);
        		}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    }
}