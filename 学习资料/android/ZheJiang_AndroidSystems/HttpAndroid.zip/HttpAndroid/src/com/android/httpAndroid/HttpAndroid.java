package com.android.httpAndroid;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class HttpAndroid extends Activity {

	private static final String TAG = "HttpAndroid";
	private TextView message;
	private Button open;
	private EditText url;

	// ������Handler
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			String m = (String) msg.obj;
			message.setText(m);
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// ��ʼ������
		setContentView(R.layout.main);
		message = (TextView) findViewById(R.id.message);
		url = (EditText) findViewById(R.id.url);
		url.setText("http://www.google.com");
		open = (Button) findViewById(R.id.open);
		open.setOnClickListener(new View.OnClickListener() {
			public void onClick(View arg0) {
				try {
					message.setText(get(url.getText().toString()));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}

	public String get(String url) throws Exception {
		HttpClient client = new DefaultHttpClient();
		HttpGet get = new HttpGet(url);
		HttpResponse response = client.execute(get);
		HttpEntity entity = response.getEntity();
		// ���Զ�ȡentity�ĳ��ȣ�����-1��ʾ����δ֪
		long length = entity.getContentLength();
		InputStream is = entity.getContent();
		String s = null;
		if (is != null) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] buf = new byte[512];
			int ch = -1;
			int count = 0;
			while ((ch = is.read(buf)) != -1) {
				baos.write(buf, 0, ch);
				count += ch;
			}
			Log.e("HttpTask", "length=" + baos.toByteArray().length);
			// ��������
			s = new String(baos.toByteArray());
		}
		return s;
		
		//д���ļ�
//		readAsFile(is, "local.txt");
//		return "";
	}

	public static void readAsFile(InputStream inSream, String string)
			throws Exception {
		FileOutputStream outStream = new FileOutputStream(string);
		byte[] buffer = new byte[1024];
		int len = -1;
		while ((len = inSream.read(buffer)) != -1) {
			outStream.write(buffer, 0, len);
		}
		outStream.close();
		inSream.close();
	}
}