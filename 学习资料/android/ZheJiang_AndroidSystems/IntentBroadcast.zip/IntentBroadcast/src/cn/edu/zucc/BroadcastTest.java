package cn.edu.zucc;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class BroadcastTest extends Activity {
	/** Called when the activity is first created. */
	// ����action��ֵ,Manifest.xml��Ҫ����Ӧ������
	private static final String ACTION_1 = "cn.edu.zucc.ACTION_1";
	private static final String ACTION_2 = "cn.edu.zucc.ACTION_2";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		menu.add(0, 0, 0, "��ʾnotification");
		menu.add(0, 1, 1, "���notification");
		return super.onCreateOptionsMenu(menu);

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case 0:
			actionOpen();
			break;
		case 1:
			actionClose();
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private void actionOpen() {
		Intent it = new Intent(ACTION_1);
		// �㲥�¼�
		sendBroadcast(it);
	}

	private void actionClose() {
		Intent it = new Intent(ACTION_2);
		sendBroadcast(it);
	}

}