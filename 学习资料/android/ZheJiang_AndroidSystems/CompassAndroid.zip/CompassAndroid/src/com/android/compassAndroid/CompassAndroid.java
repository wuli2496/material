package com.android.compassAndroid;

import android.app.Activity;
import android.os.Bundle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.view.View;

public class CompassAndroid extends Activity {

	//�洢SensorEventListener�е�float[]
	private float[] sensorValues;
	private SensorManager sensorManager;
	//ʹ��openintentsģ����ģ�⴫����ʱʹ��
//	private SensorManagerSimulator simulator;
	private CompassView view;
	private CompassSensorListener listener;
	private SensorListener sensorListener = new SensorListener() {

		public void onAccuracyChanged(int sensor, int accuracy) {

		}

		public void onSensorChanged(int sensor, float[] values) {
			switch (sensor) {
			case SensorManager.SENSOR_ORIENTATION:
				sensorValues = values;
				if (view != null)
					view.invalidate();
				break;
			}
		}
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		view = new CompassView(this);
		//����SensorManager����
		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
//		simulator = SensorManagerSimulator.getSystemService(this,
//				SENSOR_SERVICE);
//		simulator.connectSimulator();
		listener = new CompassSensorListener();
		setContentView(view);
	}

	@Override
	protected void onResume() {
		super.onResume();
		//�����豸����仯
		sensorManager.registerListener(listener, sensorManager
				.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				SensorManager.SENSOR_DELAY_FASTEST);
//		simulator
//				.registerListener(sensorListener, SensorManager.SENSOR_ORIENTATION,
//						SensorManager.SENSOR_DELAY_FASTEST);
	}

	@Override
	protected void onStop() {
		super.onStop();
		//ע��������
		sensorManager.unregisterListener(listener);
//		simulator.unregisterListener(sensorListener);
	}

	private class CompassSensorListener implements SensorEventListener {
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
		}

		public void onSensorChanged(SensorEvent event) {
			Sensor sensor = event.sensor;
			//��������仯
			switch (sensor.getType()) {
			case SensorManager.SENSOR_ORIENTATION: {
				sensorValues = event.values;
				if (view != null)
					//���»���CompassView
					view.invalidate();
				break;
			}
			}
		}
	}

	private class CompassView extends View {
		private Paint mPaint = new Paint();
		private Path mPath = new Path();

		public CompassView(Context context) {
			super(context);
			//����һ��ָ�������״
			mPath.moveTo(0, -50);
			mPath.lineTo(-20, 60);
			mPath.lineTo(0, 50);
			mPath.lineTo(20, 60);
			mPath.close();
		}

		@Override
		protected void onDraw(Canvas canvas) {
			Paint paint = mPaint;
			canvas.drawColor(Color.WHITE);
			//����paint����ʽ
			paint.setAntiAlias(true);
			paint.setColor(Color.BLACK);
			paint.setStyle(Paint.Style.FILL);
			
			int w = canvas.getWidth();
			int h = canvas.getHeight();
			int cx = w / 2;
			int cy = h / 2;
			//����任��x,y���������
			canvas.translate(cx, cy);
			if (sensorValues != null) {
				//��ת��Ļ
				canvas.rotate(-sensorValues[0]);
			}
			//����ָ����
			canvas.drawPath(mPath, mPaint);
		}
	}
}